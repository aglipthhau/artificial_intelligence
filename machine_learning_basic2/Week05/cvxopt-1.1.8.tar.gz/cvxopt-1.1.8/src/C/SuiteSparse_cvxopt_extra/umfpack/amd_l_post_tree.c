#define DLONG

#include "../../SuiteSparse/AMD/Source/amd_post_tree.c"
