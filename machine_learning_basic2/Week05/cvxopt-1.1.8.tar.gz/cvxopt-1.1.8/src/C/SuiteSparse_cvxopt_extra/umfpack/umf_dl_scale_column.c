#define DLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_scale_column.c"
