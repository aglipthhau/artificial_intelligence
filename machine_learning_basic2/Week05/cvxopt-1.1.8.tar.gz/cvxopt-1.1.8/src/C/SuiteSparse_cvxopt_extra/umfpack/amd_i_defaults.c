#define DINT

#include "../../SuiteSparse/AMD/Source/amd_defaults.c"
