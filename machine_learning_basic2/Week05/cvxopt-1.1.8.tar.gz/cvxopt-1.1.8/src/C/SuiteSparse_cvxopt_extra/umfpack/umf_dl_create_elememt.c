#define DLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_create_element.c"
