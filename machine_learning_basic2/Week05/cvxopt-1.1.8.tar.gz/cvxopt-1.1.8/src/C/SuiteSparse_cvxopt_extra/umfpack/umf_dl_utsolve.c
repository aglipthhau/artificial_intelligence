#define DLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_utsolve.c"
