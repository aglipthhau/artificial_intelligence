#define DINT

#include "../../SuiteSparse/AMD/Source/amd_aat.c"
