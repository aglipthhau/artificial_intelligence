#define DINT
#include "../../SuiteSparse/UMFPACK/Source/umf_valid_symbolic.c"
