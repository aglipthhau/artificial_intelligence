#define DINT
#include "../../SuiteSparse/UMFPACK/Source/umf_kernel_init.c"
