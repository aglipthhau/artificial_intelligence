#define DLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_scale.c"
