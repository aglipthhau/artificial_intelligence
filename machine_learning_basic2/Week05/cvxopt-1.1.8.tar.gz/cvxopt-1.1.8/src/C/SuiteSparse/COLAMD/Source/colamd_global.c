/* ========================================================================== */
/* === colamd_global.c ====================================================== */
/* ========================================================================== */

/* ----------------------------------------------------------------------------
 * COLAMD, Copyright (C) 2007, Timothy A. Davis.
 * See License.txt for the Version 2.1 of the GNU Lesser General Public License
 * http://www.suitesparse.com
 * -------------------------------------------------------------------------- */

/* Global variables for COLAMD : colamd_printf replaced with
    a function in SuiteSparse_config. */
