/* -------------------------------------------------------------------------- */
/* Copyright (c) 2005-2012 by Timothy A. Davis, http://www.suitesparse.com.   */
/* All Rights Reserved.  See ../Doc/License for License.                      */
/* -------------------------------------------------------------------------- */

GLOBAL Int UMF_store_lu
(
    NumericType *Numeric,
    WorkType *Work
) ;

GLOBAL Int UMF_store_lu_drop
(
    NumericType *Numeric,
    WorkType *Work
) ;
