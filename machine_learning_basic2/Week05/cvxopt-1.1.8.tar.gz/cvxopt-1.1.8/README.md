cvxopt
======

CVXOPT -- Python Software for Convex Optimization

Documentation available at http://cvxopt.org
